package examblock.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class ExamBlockModel {

    private ArrayList<ModelObserver> myObservers;
    private ExamList myExams;
    private Registry myRegistry;
    private RoomList myRooms;
    private SessionList mySessions;
    private StudentList myStudents;
    private SubjectList mySubjects;
    private String Title;
    private UnitList myUnits;
    private VenueList myVenues;
    private double Version;
    private String filename;


    public ExamBlockModel() {

        this.myObservers = new ArrayList<>();
        this.myExams = new ExamList(getRegistry());
        //this.myRegistry = null; // un initialized
        this.myRooms = new RoomList(this.getRegistry());
        this.mySessions = new SessionList(this.getRegistry());
        this.myStudents = new StudentList(this.getRegistry());
        this.mySubjects = new SubjectList(this.getRegistry());
        this.myUnits = new UnitList(this.getRegistry());
        this.myVenues = new VenueList(this.getRegistry());
        this.Title = "Exam Block Model"; // default?
        this.Version = 1.0;

        }
    public void addObserver(ModelObserver observer) {
        this.myObservers.add(observer);
    }

    private String getFilename() {
        return this.filename;
    }

    public ExamList getExams() {
        return this.myExams;
    }

    public Registry getRegistry() {
        return this.myRegistry;
    }

    public RoomList getRooms() {
        List<Room> rooms = this.getRegistry().getAll(Room.class);
        RoomList newList = new RoomList(this.getRegistry());
        for (Room myRoom : rooms) {
            newList.add(myRoom);
        }
        return newList;
    }

    public SessionList getSessions() {
        List<Session> sessions = this.getRegistry().getAll(Session.class);
        SessionList newList = new SessionList(this.getRegistry()); // this.items is empty at the beginning
        for (Session mySession : sessions) {
            newList.add(mySession);
        }
        return newList;
    }

    public StudentList getStudents() {
        List<Student> students = this.getRegistry().getAll(Student.class);
        StudentList newList = new StudentList(this.getRegistry());
        for (Student student : students) {
            newList.add(student);
        }
        return newList;
    }

    public SubjectList getSubjects() {
        List<Subject> subjects = this.getRegistry().getAll(Subject.class);
        SubjectList newList = new SubjectList(this.getRegistry());
        for (Subject subject : subjects) {
            newList.add(subject);
        }
        return newList;
    }

    public String getTitle() {
        return this.Title;
    }

    public UnitList getUnits() {
        List<Unit> units = this.getRegistry().getAll(Unit.class);
        UnitList newList = new UnitList(this.getRegistry());
        for (Unit unit : units) {
            newList.add(unit);
        }
        return newList;
    }

    public VenueList getVenues() {
        List<Venue> venues = this.getRegistry().getAll(Venue.class);
        VenueList newList = new VenueList(this.getRegistry());
        for (Venue venue : venues) {
            newList.add(venue);
        }
        return newList;
    }

    public double getVersion() {
        return this.Version;
    }

    public void notifyObservers(String property) {
        for (ModelObserver observer : myObservers) {
            observer.modelChanged(property);
        }
    }

    public void setFilename( String filename) {
        this.filename = filename;
    }

    public void setTitle( String title) {
        this.Title = title;
    }

    public void setVersion(double version) {
        if (this.Version <= version) {
            this.Version = version;
        }
    }

    public boolean saveToFile(Registry registry, String filename, String title, double version) {
        if (filename == null || filename.isEmpty()) {
            System.err.println("No filename provided.");
            return false;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("Title: " + title);
            writer.newLine();
            writer.write("Version: " + version);
            writer.newLine();
            writer.write("[Begin]");
            writer.newLine();

            this.mySubjects.streamOut(writer, 1);
            this.myUnits.streamOut(writer, 1);
            this.myStudents.streamOut(writer, 1);
            this.myExams.streamOut(writer, 1);
            this.myRooms.streamOut(writer, 1);
            this.myVenues.streamOut(writer, 1);
            this.mySessions.streamOut(writer, 1);

            writer.write("[End]");
            writer.newLine();
            return true;

        } catch (IOException e) {
            System.err.println("Failed to save file: " + e.getMessage());
            return false;
        }
    }




}
