package examblock.controller;

import javax.swing.*;

public class ExamBlockController {

    public ExamBlockController() {
        // Create the main window
        JFrame frame = new JFrame("Exam Block Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // Create the menu bar
        JMenuBar menuBar = new JMenuBar();

        // ----- File Menu -----
        JMenu fileMenu = new JMenu("File");
        fileMenu.add(new JMenuItem("Load..."));
        fileMenu.addSeparator();
        fileMenu.add(new JMenuItem("Save"));
        fileMenu.add(new JMenuItem("Save As"));
        fileMenu.addSeparator();
        fileMenu.add(new JMenuItem("Exit"));
        menuBar.add(fileMenu);

        // ----- View Menu -----
        JMenu viewMenu = new JMenu("View");
        viewMenu.add(new JMenuItem("Desk Allocations..."));
        viewMenu.add(new JMenuItem("Finalise Reports..."));
        menuBar.add(viewMenu);

        // Set the menu bar
        frame.setJMenuBar(menuBar);

        // Show the window
        frame.setLocationRelativeTo(null); // center the window
        frame.setVisible(true);
    }

    // Main method for testing
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExamBlockController::new);
    }
}
